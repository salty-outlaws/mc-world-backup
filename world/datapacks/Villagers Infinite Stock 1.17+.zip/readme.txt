For Minecraft 1.17 and future versions

To activate the toggles, you can use the menu that appears after a /reload, or:
	/function villagerinfstock:toggle.villagers
	/function villagerinfstock:toggle.wanderingtraders
	/function villagerinfstock:toggle.rewardexp


To uninstall the datapack run:
	/function villagerinfstock:uninstall_datapack
